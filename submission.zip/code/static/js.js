function to(url) {
    window.location.href = url;
}