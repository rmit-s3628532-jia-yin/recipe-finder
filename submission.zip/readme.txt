Team Members

Jia Yin s3628532
Chuxuan Chen s3613222

This is a recipe finder website where users can find recipes based on ingredients, they can also store their
favourite recipes on their accounts. 

website URL: http://recipe-finder.s3-website-us-east-1.amazonaws.com/ 