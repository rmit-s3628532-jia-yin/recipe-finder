window._config = {
    cognito: {
        userPoolId: 'us-east-1_UZVGgKrkb', 
        userPoolClientId: '6hqkfjac9ojkfibrvk65ttgph6', 
        region: 'us-east-1' 
    },
    api: {
        invokeUrl: 'https://y1ph0o0x8i.execute-api.us-east-1.amazonaws.com/prod'
    }
};
